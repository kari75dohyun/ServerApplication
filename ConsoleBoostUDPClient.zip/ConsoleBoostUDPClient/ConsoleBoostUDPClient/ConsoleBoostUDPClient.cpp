﻿#include <iostream>
#include <thread>
#include <atomic>
#include <chrono>
#include <boost/asio.hpp>
#include <boost/asio/ip/address.hpp>
#include "json.hpp"
#include <windows.h>
#include <winsock2.h>

using boost::asio::ip::tcp;
using boost::asio::ip::udp;
using json = nlohmann::json;

std::string g_udp_token;

std::atomic<int> g_udp_ttl_secs{ 0 };
std::atomic<long long> g_udp_token_deadline_ms{ 0 }; // epoch ms

static inline long long now_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

// 만료/미보유 시 자동 재등록 (비동기 수신 스레드가 토큰을 갱신해줌)
bool ensure_udp_token_valid(udp::socket & udp_socket,
    const udp::endpoint & udp_server_endpoint,
    const std::string & nickname) {
    const auto deadline = g_udp_token_deadline_ms.load();
    const bool expired = (g_udp_token.empty() || (deadline > 0 && now_ms() >= deadline));
    //if (!expired) return true;
    if (!expired) {
        // 디버그: 남은 TTL 출력
        auto left_ms = g_udp_token_deadline_ms.load() - now_ms();
    if (left_ms > 0) {
        std::cout << "[UDP] 남은 토큰 TTL ≈ " << (left_ms / 1000) << "s\n";
    }
    return true;
}
    // 재등록 전송
    json udp_reg_msg;
    udp_reg_msg["type"] = "udp_register";
    udp_reg_msg["nickname"] = nickname;
    const std::string reg_str = udp_reg_msg.dump();
    boost::system::error_code ec;
    udp_socket.send_to(boost::asio::buffer(reg_str), udp_server_endpoint, 0, ec);
    std::cout << "[UDP][재등록] 토큰 없음/만료 -> 재등록 패킷 전송: " << reg_str << std::endl;
    if (ec) {
        std::cout << "[UDP][재등록] 전송 실패: " << ec.message() << std::endl;
    }
    // 이번 입력은 건너뛰고, 다음 입력에서 갱신된 토큰으로 보내도록 유도
    return false;
}

// 패킷 송신 함수 (길이 헤더 + JSON)
void send_packet_with_length(tcp::socket& tcp_socket, const std::string& json_str) {
    uint32_t len = static_cast<uint32_t>(json_str.size());
    uint32_t netlen = htonl(len);
    std::vector<char> packet(4 + len);
    memcpy(packet.data(), &netlen, 4);
    memcpy(packet.data() + 4, json_str.data(), len);
    boost::asio::write(tcp_socket, boost::asio::buffer(packet));
}

// SSL 읽기 스레드 (종료 플래그 참조)
void tcp_read_loop(tcp::socket& tcp_socket, std::atomic<bool>& running) {
    std::vector<char> buffer;
    try {
        for (;;) {
            if (!running) break;
            char data[2048] = { 0 };
            size_t len = tcp_socket.read_some(boost::asio::buffer(data));
            if (len == 0) break;
            buffer.insert(buffer.end(), data, data + len);

            while (buffer.size() >= 4) {
                uint32_t msg_len = 0;
                memcpy(&msg_len, buffer.data(), 4);
                msg_len = ntohl(msg_len);
                if (buffer.size() < 4 + msg_len) break;

                std::string one_message(buffer.begin() + 4, buffer.begin() + 4 + msg_len);
                buffer.erase(buffer.begin(), buffer.begin() + 4 + msg_len);

                try {
                    json msg = json::parse(one_message);
                    std::string type = msg.value("type", "");
                    if (type == "notice") {
                        std::cout << "[알림] " << msg.value("msg", "") << std::endl;
                    }
                    else if (type == "udp_token") {
                        g_udp_token = msg.value("token", "");
                        std::cout << "[UDP] 서버에서 토큰 발급: " << g_udp_token << std::endl;
                    }
                    else if (type == "chat") {
                        std::cout << "[" << msg.value("from", "") << "] " << msg.value("msg", "") << std::endl;
                    }
                    else if (type == "chat_zone") {
                        std::cout << "[" << msg.value("from", "") << "][Zone] " << msg.value("msg", "") << std::endl;
					}
                    else if (type == "whisper") {
                        std::cout << "[귓속말][" << msg.value("from", "") << "] " << msg.value("msg", "") << std::endl;
                    }
                    else if (type == "logout") {
                        std::cout << "[로그아웃] " << msg.value("msg", "") << std::endl;
                        running = false;

                        // socket 종료
                        try { tcp_socket.close(); }
                        catch (...) {}
                        break;
                    }
                    else if (type == "login_success") {
                        std::cout << "[로그인 성공] " << msg.value("nickname", "") << std::endl;
                    }
                    else {
                        std::cout << "[서버] " << msg.dump() << std::endl;
                    }
                }
                catch (...) {
                    std::cout << "[수신][TCP/SSL] (JSON 아님) " << one_message << std::endl;
                }
            }
        }
    }
    catch (std::exception& e) {
        if (std::string(e.what()).find("End of file") == std::string::npos) {
            std::cerr << "[TCP/SSL] Read error: " << e.what() << std::endl;
        }
        running = false;
    }
    try { tcp_socket.close(); }
    catch (...) {}
}

// UDP 읽기 스레드
void udp_read_loop(boost::asio::io_context& io, udp::socket& udp_socket, std::atomic<bool>& running) {
    char buffer[2048];
    udp::endpoint sender_endpoint;
    while (running) {
        boost::system::error_code ec;
        size_t len = udp_socket.receive_from(boost::asio::buffer(buffer), sender_endpoint, 0, ec);
        if (!ec && len > 0) {
            std::string msg(buffer, len);
            try {
                auto jmsg = json::parse(msg);
                std::string type = jmsg.value("type", "");
                if (type == "udp_register_ack") {

                    //g_udp_token = jmsg.value("token", "");
                    ////std::cout << "[UDP][등록확인] token 저장됨: " << g_udp_token << std::endl;

                    //int ttl = jmsg.value("ttl", 0);
                    //g_udp_ttl_secs.store(ttl);
                    //if (ttl > 0) {
                    //    g_udp_token_deadline_ms.store(now_ms() + static_cast<long long>(ttl) * 1000LL);
                    //}
                    //else {
                    //    // TTL 미제공 시 0 = 만료관리 안함(서버 정책)
                    //    g_udp_token_deadline_ms.store(0);
                    //}
                    //std::cout << "[UDP][등록확인] token 저장됨: " << g_udp_token;
                    //if (ttl > 0) std::cout << " (ttl=" << ttl << "s)";
                    //std::cout << std::endl;
                    g_udp_token = jmsg.value("token", "");
                    // 서버가 ttl을 안 주는 경우를 대비한 안전장치(서버 기본 300s로 가정)
                    int ttl = jmsg.value("ttl", 0);
                    if (ttl <= 0) ttl = 300; // fallback TTL
                    g_udp_ttl_secs.store(ttl);
                    g_udp_token_deadline_ms.store(now_ms() + static_cast<long long>(ttl) * 1000LL);
                    std::cout << "[UDP][등록확인] token 저장됨: " << g_udp_token
                        << " (ttl=" << ttl << "s)" << std::endl;
                }
                else if (type == "udp_reply") {
                    std::cout << "[UDP][에코/응답] " << jmsg.value("msg", "") << std::endl;
                }
                else if (type == "broadcast_udp") {
                    std::cout << "[" << "UDP BroadCast " << jmsg.value("nickname", "") << " ] " << jmsg.value("msg", "") << std::endl;
                }
                else if (type == "broadcast_udp_zone") {
                    std::cout << "[" << "UDP BroadCast Zone " << jmsg.value("nickname", "") << " ] " << jmsg.value("msg", "") << std::endl;
                }
                else if (type == "udp_error") {
                    ////std::cout << "[UDP][오류] " << jmsg.value("error", "알 수 없는 오류") << std::endl;
                    //const std::string err = jmsg.value("error", "알 수 없는 오류");
                    //std::cout << "[UDP][오류] " << err << std::endl;
                    //// 만료 관련 에러면 즉시 재등록 전송
                    //    if (err.find("expired") != std::string::npos ||
                    //        err.find("Invalid UDP token") != std::string::npos) {
                    //    // 토큰 무효화하고 재등록 트리거
                    //    g_udp_token.clear();
                    //    g_udp_token_deadline_ms.store(0);
                    //    // 누구 닉네임인지 모를 수 있으므로 안내만. (main 루프에서 ur: 또는 다음 입력 시 자동 재등록)
                    //        std::cout << "[UDP] 토큰 만료 감지 -> 'ur:' 또는 다음 UDP 입력 시 자동 재등록 됩니다." << std::endl;
                    //}
                    // 
                    // 서버가 'error' 대신 'msg'를 보낼 수도 있으니 모두 체크
                    std::string err = jmsg.value("error", "");
                    if (err.empty()) err = jmsg.value("msg", "");
                    if (err.empty()) err = jmsg.dump(); // 원문 출력
                    std::cout << "[UDP][오류] " << err << std::endl;
                        // 어떤 udp_error든 토큰은 의심 상태로 보고 재등록 유도(보수적 처리)
                        g_udp_token.clear();
                    g_udp_token_deadline_ms.store(0);
                    std::cout << "[UDP] 오류 감지 -> 'ur:' 또는 다음 UDP 입력 시 자동 재등록 됩니다." << std::endl;
                }
                else if (type == "keepalive") {
                    continue;
                }
                else {
                    std::cout << "[UDP][수신] " << jmsg.dump() << std::endl;
                }
            }
            catch (...) {
                std::cout << "[UDP][수신] (JSON 아님) " << msg << std::endl;
            }
        }
        if (ec) break;
    }
}

// Keepalive 스레드
void keepalive_loop(tcp::socket& tcp_socket, std::atomic<bool>& running) {
    try {
        while (running) {
            json keepalive_msg;
            keepalive_msg["type"] = "keepalive";
            send_packet_with_length(tcp_socket, keepalive_msg.dump());
            std::this_thread::sleep_for(std::chrono::seconds(20));
        }
    }
    catch (const std::exception& e) {
        std::cerr << "[Keepalive 예외] " << e.what() << std::endl;
        running = false;
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    setlocale(LC_ALL, "");

    try {
        boost::asio::io_context io;

        // TCP
        tcp::socket tcp_socket(io);

        tcp::resolver resolver(io);
        auto endpoints = resolver.resolve("127.0.0.1", "12345");

        boost::asio::connect(tcp_socket, endpoints);

        std::cout << "Connected to SSL server (127.0.0.1:12345)\n";

        // UDP 준비
        udp::endpoint udp_server_endpoint(boost::asio::ip::make_address("127.0.0.1"), 54321);

        udp::socket udp_socket(io);
        udp_socket.open(udp::v4());
        udp_socket.bind(udp::endpoint(udp::v4(), 0)); // 임의 포트 바인드

        auto local_endpoint = udp_socket.local_endpoint();
        std::cout << "UDP client bound to " << local_endpoint.address().to_string() << ":" << local_endpoint.port() << std::endl;

        std::atomic<bool> running{ true };

        // 스레드 시작
        std::thread tcp_read_thread(tcp_read_loop, std::ref(tcp_socket), std::ref(running));
        std::thread udp_read_thread(udp_read_loop, std::ref(io), std::ref(udp_socket), std::ref(running));
        std::thread keepalive_thread(keepalive_loop, std::ref(tcp_socket), std::ref(running));

        // 로그인
        std::cout << "Enter your nickname: ";
        std::string nickname;
        std::getline(std::cin, nickname);

        json login_msg;
        login_msg["type"] = "login";
        login_msg["nickname"] = nickname;
        send_packet_with_length(tcp_socket, login_msg.dump());

        std::this_thread::sleep_for(std::chrono::seconds(5)); // 서버 세션 준비 대기

        if (nickname != "quit") {
            json udp_reg_msg;
            udp_reg_msg["type"] = "udp_register";
            udp_reg_msg["nickname"] = nickname;
            std::string reg_str = udp_reg_msg.dump();
            udp_socket.send_to(boost::asio::buffer(reg_str), udp_server_endpoint);
            std::cout << "[UDP][등록] 자동 UDP endpoint 등록 패킷 전송: " << reg_str << std::endl;
        }

        // 채팅 입력 루프
        std::string line;
        while (running && std::getline(std::cin, line)) {
            if (!running) break;

            if (line.rfind("u:", 0) == 0) {
                std::string udp_text = line.substr(2);
                //json udp_msg;
                //udp_msg["type"] = "udp";
                //udp_msg["nickname"] = nickname;
                //udp_msg["token"] = g_udp_token;
                //udp_msg["msg"] = udp_text;
                //std::string send_str = udp_msg.dump();
                //udp_socket.send_to(boost::asio::buffer(send_str), udp_server_endpoint);
                //std::cout << "[UDP][송신] " << send_str << std::endl;
                if (!ensure_udp_token_valid(udp_socket, udp_server_endpoint, nickname)) {
                    std::cout << "[UDP] 토큰 재등록 요청을 보냈습니다. 잠시 후 다시 시도하세요." << std::endl;
                }
                else {
                    json udp_msg;
                    udp_msg["type"] = "udp";
                    udp_msg["nickname"] = nickname;
                    udp_msg["token"] = g_udp_token;
                    udp_msg["msg"] = udp_text;
                    std::string send_str = udp_msg.dump();
                    udp_socket.send_to(boost::asio::buffer(send_str), udp_server_endpoint);
                    std::cout << "[UDP][송신] " << send_str << std::endl;
                }
            }
            else if (line == "ur:") {
                json udp_reg_msg;
                udp_reg_msg["type"] = "udp_register";
                udp_reg_msg["nickname"] = nickname;
                std::string reg_str = udp_reg_msg.dump();
                udp_socket.send_to(boost::asio::buffer(reg_str), udp_server_endpoint);
                std::cout << "[UDP][등록] 자동 UDP endpoint 등록 패킷 전송: " << reg_str << std::endl;
            }
            else if (line.rfind("ub:", 0) == 0) {
                std::string udp_text = line.substr(3);
                //json udp_msg;
                //udp_msg["type"] = "broadcast_udp";
                //udp_msg["nickname"] = nickname;
                //udp_msg["token"] = g_udp_token;
                //udp_msg["msg"] = udp_text;
                //std::string send_str = udp_msg.dump();
                //udp_socket.send_to(boost::asio::buffer(send_str), udp_server_endpoint);
                //std::cout << "[UDP][브로드캐스트 송신] " << send_str << std::endl;
                if (!ensure_udp_token_valid(udp_socket, udp_server_endpoint, nickname)) {
                    std::cout << "[UDP] 토큰 재등록 요청을 보냈습니다. 잠시 후 다시 시도하세요." << std::endl;
                }
                else {
                    json udp_msg;
                    udp_msg["type"] = "broadcast_udp";
                    udp_msg["nickname"] = nickname;
                    udp_msg["token"] = g_udp_token;
                    udp_msg["msg"] = udp_text;
                    std::string send_str = udp_msg.dump();
                    udp_socket.send_to(boost::asio::buffer(send_str), udp_server_endpoint);
                    std::cout << "[UDP][브로드캐스트 송신] " << send_str << std::endl;
                }
            }
            else if (line.rfind("ubz:", 0) == 0) {
                std::string udp_text = line.substr(4);
                //json udp_msg;
                //udp_msg["type"] = "broadcast_udp_zone";
                //udp_msg["nickname"] = nickname;
                //udp_msg["token"] = g_udp_token;
                //udp_msg["msg"] = udp_text;
                //std::string send_str = udp_msg.dump();
                //udp_socket.send_to(boost::asio::buffer(send_str), udp_server_endpoint);
                //std::cout << "[UDP][브로드캐스트 ZONE 송신] " << send_str << std::endl;
                if (!ensure_udp_token_valid(udp_socket, udp_server_endpoint, nickname)) {
                    std::cout << "[UDP] 토큰 재등록 요청을 보냈습니다. 잠시 후 다시 시도하세요." << std::endl;
                }
                else {
                    json udp_msg;
                    udp_msg["type"] = "broadcast_udp_zone";
                    udp_msg["nickname"] = nickname;
                    udp_msg["token"] = g_udp_token;
                    udp_msg["msg"] = udp_text;
                    std::string send_str = udp_msg.dump();
                    udp_socket.send_to(boost::asio::buffer(send_str), udp_server_endpoint);
                    std::cout << "[UDP][브로드캐스트 ZONE 송신] " << send_str << std::endl;
                }
            }
            else if (line == "quit") {
                json quit_msg;
                quit_msg["type"] = "logout";
                send_packet_with_length(tcp_socket, quit_msg.dump());
                running = false;
                break;
            }
            else if (line.rfind("tbz:", 0) == 0) {
                std::string tcp_text = line.substr(4);
                json chat_msg;
                chat_msg["type"] = "chat_zone";
                chat_msg["msg"] = tcp_text;
                try {
                    send_packet_with_length(tcp_socket, chat_msg.dump());
                }
                catch (const std::exception& e) {
                    std::cerr << "[chat_msg.dump 예외] " << e.what() << std::endl;
                }
            }
            else {
                json chat_msg;
                chat_msg["type"] = "chat";
                chat_msg["msg"] = line;
                try {
                    send_packet_with_length(tcp_socket, chat_msg.dump());
                }
                catch (const std::exception& e) {
                    std::cerr << "[chat_msg.dump 예외] " << e.what() << std::endl;
                }
            }
        }

        //running = false;

        try { tcp_socket.close(); }
        catch (...) {}

        try { udp_socket.close(); }
        catch (...) {}

        if (keepalive_thread.joinable()) keepalive_thread.join();
        if (tcp_read_thread.joinable()) tcp_read_thread.join();
        if (udp_read_thread.joinable()) udp_read_thread.join();

        std::cout << "[클라이언트] 안전하게 종료되었습니다." << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "[Main] Exception: " << e.what() << std::endl;
    }
    return 0;
}
